#ifndef	SOURCES_H
#define SOURCES_H

#define	CITYEDIT_C	FAR
#define	CITYCMD_C	FAR
#define	CITYCMDB_C	FAR
#define	CITYCMDC_C	FAR
#define	CITYCMDD_C	FAR
#define	CITYCMDE_C	FAR
#define	SHOWFACE_C	FAR
#define	TACTIC_C	FAR
#define	PACCOUNT_C	FAR
#define	INFDEAL_C	FAR

#endif
