#pragma once

#include "stdafx.h"

using namespace std;

class CEngine
{
	// ��������
public:
	CEngine(istream *sInStream);
	bool Process(void);
	stringstream * GetOutStream(void);
	int GetType(void) const;
	int GetIndex(void) const;
	int GetLength(void) const;
	virtual ~CEngine(void);

	// TypeDef ����
	typedef unsigned char byte;
	typedef unsigned short int word;
	typedef unsigned int dword;

private:
	// �����������ȡһ���ֽ�
	byte ReadByte(void) const;
	// �����������ȡһ����
	word ReadWord(void) const;
	dword ReadDword(void) const;
	void SetJumpTable(void);
	void SetLabelFlag(word wIndex);
	const char * FormatParam(const char* szParam);
	const char * GetTagName(byte iIndex) const;
	const char * GetTagParam(byte iIndex) const;
	bool FileIsValid(int iGutSize);

	// �ݲ�ʵ��,˽�л��Է�����
	CEngine(const CEngine &right);
	CEngine & operator = (const CEngine &right);

	// ��������
private:
	// ������
	istream *m_InStream;
	// �����
	stringstream *m_strStream;
	byte m_byType;
	byte m_byIndex;
	byte m_byJumpTableSize;
	word m_wLength;
	word *m_wJumpTable;
	bool *m_bLabelFlags;

	// ͷ����ַƫ��
	static const unsigned int uBaseAddr = 0x18;

private:
	class CCommand
	{
	public:
		CCommand();
		CCommand(const CCommand &right);
		virtual ~CCommand();
		CCommand & operator = (const CCommand &right);

		void SetText(const char * szText);
		const char * GetText(void) const;
		void SetAddress(const word & wAddr);
		word GetAddress(void) const;

		// ����ID
		enum TAG_ID : byte
		{
			Music = 0x00,
			LoadMap,
			CreateActor,
			DeleteNpc,
			MapEvent,
			ActorEvent,
			Move,
			ActorMove,
			ActorSpeed,
			Callback,
			Goto,
			If,
			Set,
			Say,
			StartChapter,
			ScreenR,
			ScreenS,
			ScreenA,
			Event,
			Money,
			Gameover,
			IfCmp,
			Add,
			Sub,
			SetControlId,
			GutEvent,
			SetEvent,
			ClrEvent,
			Buy,
			FaceToFace,
			Movie,
			Choice,
			CreateBox,
			DeleteBox,
			GainGoods,
			InitFight,
			FightEnable,
			FightDisenable,
			CreateNpc,
			EnterFight,
			DeleteActor,
			GainMoney,
			UseMoney,
			SetMoney,
			LearnMagic,
			Sale,
			NpcMoveMod,
			Message,
			DeleteGoods,
			ResumeActorHp,
			ActorLayerUp,
			BoxOpen,
			DelAllNpc,
			NpcStep,
			SetSceneName,
			ShowSceneName,
			ShowScreen,
			UseGoods,
			AttribTest,
			AttribSet,
			AttribAdd,
			ShowGut,
			UseGoodsNum,
			Randrade,
			Menu,
			TestMoney,
			CallChapter,
			DisCmp,
			Return,
			TimeMsg,
			DisableSave,
			EnableSave,
			GameSave,
			SetEventTimer,
			EnableShowPos,
			DisableShowPos,
			SetTo,
			TestGoodsNum,
			END
		};

	private:
		word m_wAddr;
		char *m_szText;
	};
};
