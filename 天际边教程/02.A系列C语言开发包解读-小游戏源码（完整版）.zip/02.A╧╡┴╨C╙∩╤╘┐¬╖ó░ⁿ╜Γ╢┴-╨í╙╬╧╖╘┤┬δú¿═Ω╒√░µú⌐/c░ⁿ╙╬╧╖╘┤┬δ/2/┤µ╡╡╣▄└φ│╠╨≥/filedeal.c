#include "inc\dictafx.h"
#include "inc\keytable.h"
#include "tran.h"
#include "filedeal.h"


extern U8 *g_filedata;
extern TranType pTran;
extern U8 tranbuf[255];
extern U8 readbuf[150];
extern U8 writebuf[150];

extern U8 notestring[40];

extern U16 listtop;
extern U16 listset;
extern U16 listlen;

extern U16 fnames[LISTSHOWMAX];

extern U8	fpInf[12];
extern U16	flen;
extern TranFileType filetran;
extern FileInf fileinf;
extern U8 tranendflag;
extern U16 doff;

#include "lib_fileop.c"

U8 ShowFileList();
U8 FunKeyDeal(U8 key);
void RevDataPackDeal();

void FileDeal()
{
	MsgType msg;
	
	listtop = 0;
	listset = 0;
	/* ��ʼ��ϵͳ */
	GuiInit();
	SysMemInit(MEM_HEAP_START,MEM_HEAP_SIZE);
	SysIconAllClear();
		
	SysCls();
	
	
	if (ShowFileList())
	{
		SysMemcpy(notestring,"����Ϸ�浵",12);
		GuiMsgBox(notestring,200);
	}
	
	/*g_filedata=SysMemAllocate(FDATABUFLEN + 50);

	if(NULL==g_filedata)
	{
		SysMemcpy(notestring,"�����ڴ�ʧ��",14);
		GuiMsgBox(notestring,200);
		return;
	}*/
	
	while(1)
	{
		if(!GuiGetMsg(&msg))		continue;
		if(!GuiTranslateMsg(&msg))	continue;
		
		/*if (msg.type == WM_TIMER)
		{

			if (Communication(&pTran))
			{
				return(2);
			}
			
			if(IsWriterBuffer(&pTran))
				continue;
			
			TimerDeal();
		}
		else if (msg.type == WM_COM)
		{
			if (ReceiveManage(&pTran))
			{
				return(1);
			}
		}
		else if (msg.type == WM_RECEIVED)
		{
			if (ReadData(&pTran,tranbuf))
			{
				if (TranPackDeal())
					return(3);
			}
		}*/
		else if (msg.type == WM_CHAR_ASC || msg.type == WM_CHAR_FUN)
		{
			switch (FunKeyDeal(msg.param))
			{
			case 0:
				/*SysMemFree(g_filedata);*/
				CloseTran();
				return;
			case 1:
				if (ShowFileList())
				{
					SysMemcpy(notestring,"����Ϸ�浵",12);
					GuiMsgBox(notestring,200);
					/*SysMemFree(g_filedata);
					CloseTran();
					return;*/
				}
				break;
				
			}
		}
	}
}


U8 ShowFileList()
{
	U8	err;
	U16	pfNum,i,tmpName;
	U32	pLen;
	
	
	SysLcdPartClear(0,FONTHIG,FONTHIG * 5 - 1,FONTHIG * LISTSHOWMAX + FONTHIG - 1);
	
	SysMemcpy(notestring,"s������,r������",20);
	SysPrintString(FONTHIG,0,notestring);
	
	FileNum(GAME_SAVE,&listlen);
	if (!listlen)
		return(1);
		
	if (listtop + LISTSHOWMAX > listlen)
	{
		if (listlen > LISTSHOWMAX)
			listtop = listlen - LISTSHOWMAX;
	}
	
	if (listlen < LISTSHOWMAX)
		listtop = 0;
	
	fpInf[10] = 0;
	for (i = 1;i <= LISTSHOWMAX;i ++)
	{
		if (listtop + i > listlen)
			break;
		
		
		FileSearch(GAME_SAVE,listtop + i,&fnames[i - 1],fpInf);
		/*if(!err) return(2);*/
		SysPrintString(0,i * FONTHIG,fpInf);
		
		if (listtop + i == listset + 1)
			SysMemcpy(fileinf.finf,fpInf,10);
	}
	
	SysLcdReverse(0,(listset - listtop + 1) * FONTHIG,FONTHIG * 5 - 1,(listset - listtop + 2) * FONTHIG - 1);
	return(0);
}

U8 FunKeyDeal(U8 key)
{
	switch (key)
	{
	case CHAR_RIGHT:
	case CHAR_DOWN:
		if (!listlen)
			return(1);
		if (listset < listlen - 1)
		{
			listset += 1;
			if (listtop + LISTSHOWMAX <= listset)
				listtop += 1;
		}
		return(1);
	case CHAR_LEFT:
	case CHAR_UP:
		if (!listlen)
			return(1);
		if (listset)
		{
			listset -= 1;
			if (listtop > listset)
				listtop = listset;
		}
		return(1);
	case CHAR_DEL:
		if (!listlen)
			return(1);
		SysMemcpy(notestring,"ɾ���浵��",12);
		if(GuiQueryBox(0,0,notestring))
			return(1);
			
		if (GamFileOp(fpInf,fnames[listset - listtop],g_filedata,OPEN_D,&flen))
		{
			SysMemcpy(notestring,"�ļ�����ʧ��",10);
			GuiMsgBox(notestring,200);
		}
		else
		{
			if (listset == listlen - 1)
			{
				listset -= 1;
			}
		}
		return(1);
	case CHAR_EXIT:
		return(0);
	case 's':
	case 'S':
		if (!listlen)
		{
			SysMemcpy(notestring,"����Ϸ�浵",12);
			GuiMsgBox(notestring,200);
			return(1);
		}
		SysMemcpy(notestring,"���ʹ浵��",12);
		if(GuiQueryBox(0,0,notestring))
			return(1);
		
		g_filedata=SysMemAllocate(FDATABUFLEN + 50);
		if(NULL==g_filedata)
		{
			SysMemcpy(notestring,"�����ڴ�ʧ��",14);
			GuiMsgBox(notestring,200);
			return(1);
		}
		
		if (GamFileOp(fpInf,fnames[listset - listtop],g_filedata,OPEN_R,&flen))
		{
			SysMemcpy(notestring,"�ļ�����ʧ��",14);
			GuiMsgBox(notestring,200);
		}
		else
		{
			fileinf.ftype = GAME_SAVE;
			fileinf.flen = flen;
			switch (FileDataSend())
			{
			case 0xf0:
				SysMemcpy(notestring,"���ͳɹ�",10);
				break;
			case 0x08:
				SysMemcpy(notestring,"����ȡ��",10);
				break;
			default:
				SysMemcpy(notestring,"ͨѶʧ��",10);
				break;
			}
			GuiMsgBox(notestring,200);
		}
		
		SysCls();
		SysMemFree(g_filedata);
		return(1);
	case 'r':
	case 'R':		
		g_filedata=SysMemAllocate(FDATABUFLEN + 50);

		if(NULL==g_filedata)
		{
			SysMemcpy(notestring,"�����ڴ�ʧ��",14);
			GuiMsgBox(notestring,200);
			return(1);
		}
		
		switch (FileDataRev())
		{
		case 0xf0:
			SysMemcpy(notestring,"���ճɹ�",10);
			GuiMsgBox(notestring,200);
			break;
		case 0x08:
			SysMemcpy(notestring,"����ȡ��",10);
			GuiMsgBox(notestring,200);
			SysMemFree(g_filedata);
			SysCls();
			return(1);
		default:
			SysMemcpy(notestring,"ͨѶʧ��",10);
			GuiMsgBox(notestring,200);
			SysMemFree(g_filedata);
			SysCls();
			return(1);
		}
		
		if (GamFileOp(fileinf.finf,0,g_filedata,OPEN_W,&fileinf.flen))
		{
			SysMemcpy(notestring,"�����ļ�ʧ��",14);
		}
		else
		{
			SysMemcpy(notestring,"�����ļ��ɹ�",14);
		}
		GuiMsgBox(notestring,200);
		
		SysMemFree(g_filedata);
		SysCls();
		return(1);
	}
	return(1);
}


FAR U8 FileDataRev()
{
	U8 rlen;
	MsgType msg;
	
	tranendflag = 0;
	if (TradeServer())
	{
		return(1);
	}
	
	SysMemcpy(notestring,"���ݽ�����",12);
	SysPrintString(FONTHIG * 2,FONTHIG * 2,notestring);
	
	fileinf.ftype = 0xff;
	fileinf.flen = 10;
	doff = 0;
	SysTimer1Open(20);
	while(1)
	{
		if(!GuiGetMsg(&msg))		continue;
		if(!GuiTranslateMsg(&msg))	continue;
		
		if (msg.type == WM_TIMER)
		{

			if (Communication(&pTran))
			{
				SysTimer1Close();
				return(2);
			}
			
			if(IsWriterBuffer(&pTran))
				continue;
				
			if (tranendflag == 0x90)
			{
				filetran.type = CANCELSEND;
				SendData(&pTran,(U8 *) &filetran,10);
				tranendflag = 0x08;
				continue;
			}
			
			if (tranendflag)
			{
				SysTimer1Close();
				return(tranendflag);
			}
			
		}
		else if (msg.type == WM_COM)
		{
			if (ReceiveManage(&pTran))
			{
				SysTimer1Close();
				return(1);
			}
		}
		else if (msg.type == WM_RECEIVED)
		{
			rlen = ReadData(&pTran,(U8 *) &filetran);
			if (rlen)
			{
				RevDataPackDeal();
			}
		}
		else if (msg.type == WM_CHAR_FUN)
		{
			switch (msg.param)
			{
			case CHAR_EXIT:
				tranendflag = 0x90;
				break;
			}
		}
	}
}

void RevDataPackDeal()
{
	switch (filetran.type)
	{
	case FILEINF:
		SysMemcpy((U8 *) &fileinf,filetran.fdata,sizeof(FileInf));
		SysMemcpy(notestring,fileinf.finf,12);
		notestring[10] = 0;
		SysPrintString(FONTHIG * 2,FONTHIG * 3,notestring);
		itoa(fileinf.flen,notestring,10);
		SysPrintString(FONTHIG * 2,FONTHIG * 4,notestring);
		doff = 0;
		break;
	case FILEDATA:
		if (fileinf.ftype == 0xff)
		{
			tranendflag = 0x0f;
			return;
		}
		SysMemcpy(&g_filedata[doff],filetran.fdata,TRANDATALEN);
		doff += TRANDATALEN;
		break;
	case FILEEND:
		if (fileinf.ftype == 0xff)
		{
			tranendflag = 0x0f;
			return;
		}
		tranendflag = 0xf0;
		break;
	case CANCELSEND:
		tranendflag = 0x08;
		break;
	default:
		tranendflag = 0x0f;
		break;
	}
}

