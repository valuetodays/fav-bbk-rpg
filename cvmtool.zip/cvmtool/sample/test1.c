char ss[60];

void printchar(char c)
{
	asm("SI_LCONST 1");
	asm("_syscall");
}

void printstring(char *str)
{
	asm("SI_LCONST 2");
	asm("_syscall");
}

