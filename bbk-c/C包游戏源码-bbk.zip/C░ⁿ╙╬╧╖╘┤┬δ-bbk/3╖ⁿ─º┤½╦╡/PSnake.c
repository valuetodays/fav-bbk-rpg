#include "inc\dictsys.h"
#include "inc\keytable.h"
#include "inc\stdlib.h"
#include "inc\flash.h"

extern U8 *ax,*ay,*bx,*by,*exit,*gamemain,*kw;
extern U8 *s1_1,*s1_2,*s1_3,*s2_1,*s2_2,*s2_3,*s3_1,*s3_2,*s3_3;
extern U8 *readme[12];
extern U8 *s1enter[19];
FAR void Readme();
FAR void S1enter();

FAR U8 GameTanShiShe()
{
	GuiInit();	/*Gui OS ��ʼ����ʹ��ǰһ��Ҫ���� */
	SysMemInit(MEM_HEAP_START,MEM_HEAP_SIZE);	/*��ʼ����*/
	SysIconAllClear();
    SysLCDClear();
	int a=1;
	MsgType key;
start1:SysLCDClear();
	SysPrintString(0,0,gamemain);
	SysPrintString(32,24,s1_1);
	SysPrintString(32,48,s1_2);
	SysPrintString(32,72,s1_3);
A:GuiSetKbdType(SYS_ENG_KBD);
	GuiGetMsg(&key);
	GuiTranslateMsg(&key);
	if(key.type==WM_CHAR_FUN)
		{
		if(key.param==CHAR_UP)
			goto start3;
		else if(key.param==CHAR_DOWN)
			goto start2;
		else if(key.param==CHAR_ENTER){
			S1enter();
			goto gamebegin;}
		
	}
	goto A;
start2:SysLCDClear();
	   SysPrintString(0,0,gamemain);
	SysPrintString(32,24,s2_1);
	SysPrintString(32,48,s2_2);
	SysPrintString(32,72,s2_3);
B:GuiSetKbdType(SYS_ENG_KBD);
	GuiGetMsg(&key);
	GuiTranslateMsg(&key);
	if(key.type==WM_CHAR_FUN)
		{
		if(key.param==CHAR_UP){
			goto start1;
		}
		else if(key.param==CHAR_DOWN){
			goto start3;}
		else if(key.param==CHAR_ENTER){
			Readme();
			goto start2;
		}
		
	}
	goto B;
start3:SysLCDClear();
	   SysPrintString(0,0,gamemain);
	SysPrintString(32,24,s3_1);
	SysPrintString(32,48,s3_2);
	SysPrintString(32,72,s3_3);
C:GuiSetKbdType(SYS_ENG_KBD);
	GuiGetMsg(&key);
	GuiTranslateMsg(&key);
	if(key.type==WM_CHAR_FUN)
		{
		if(key.param==CHAR_UP)
			goto start2;
		else if(key.param==CHAR_DOWN)
			goto start1;
		else if(key.param==CHAR_ENTER)
			goto as;
	}
	goto C;
as:SysLCDClear();
   SysPrintString(25,35,exit);
   GuiGetMsg(&key);
   return(1);

gamebegin:SysLCDClear();


}
/*-----------------------------------�������ڹ�����------------------------------------*/


/*-----------------------------------�������ں���������---------------------------------*/
/*Readme����*/
/*��ʾ��Ϸ˵��*/
FAR void Readme()
{
	int a=1;
	MsgType key;
	ius:SysLCDClear();
	SysPrintString(0,0,readme[a]);
	SysPrintString(0,16,readme[a+1]);
	SysPrintString(0,32,readme[a+2]);
	SysPrintString(0,48,readme[a+3]);
	SysPrintString(0,64,readme[a+4]);
	SysPrintString(0,80,readme[a+5]);
key1:GuiSetKbdType(SYS_ENG_KBD);
	GuiGetMsg(&key);
	GuiTranslateMsg(&key);
	if(key.type==WM_CHAR_FUN)
		{
		if(key.param==CHAR_DOWN){
			a+=1;
			goto pas1;
		}
		else if(key.param==CHAR_UP){
			a-=1;
			goto pas1;
		}
		else if(key.param==CHAR_PGUP){
			a-=6;
			goto pas1;
		}
		else if(key.param==CHAR_PGDN){
			a+=6;
			goto pas1;
		}
		else if(key.param==CHAR_EXIT){
			a=1;
			return;
		}
		goto key1;
	}
pas1:if(a>6){
		 a=6;
	 }
	 else if(a<1){
		 a=1;
	 }
	 goto ius;
}




/*��Ϸ��ͷ˵��*/

FAR void S1enter()
{
	MsgType key;
	int a=1;
ius2:SysLCDClear();
	SysPrintString(0,0,s1enter[a]);
	SysPrintString(0,16,s1enter[a+1]);
	SysPrintString(0,32,s1enter[a+2]);
	SysPrintString(0,48,s1enter[a+3]);
	SysPrintString(0,64,s1enter[a+4]);
	SysPrintString(0,80,s1enter[a+5]);
key3:GuiSetKbdType(SYS_ENG_KBD);
	GuiGetMsg(&key);
	GuiTranslateMsg(&key);
	if(key.type==WM_CHAR_FUN)
		{
		if(key.param==CHAR_ENTER){
			a+=6;
			goto pas2;
		}
		goto key3;
	}
pas2:if(a>15){
		return;
	}
	goto ius2;
}
