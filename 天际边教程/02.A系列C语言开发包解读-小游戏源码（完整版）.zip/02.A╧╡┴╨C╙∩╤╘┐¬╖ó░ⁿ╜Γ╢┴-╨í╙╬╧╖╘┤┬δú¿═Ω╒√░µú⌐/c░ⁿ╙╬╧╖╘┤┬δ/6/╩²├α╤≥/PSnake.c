#include "sheep.h"

extern U8 MainPicture[],*GameName,*filena[4];

FAR U8 GameTanShiShe()
{
	int k;
	int speed=1;
	int GQ=1;
	int i=0;
	int IQ=0;
	int c=0;
	Maind();
	SysIconAllClear();
	Cls();
	SysPicture(0,0,158,95,MainPicture,0);
	DelayFalse(250);
	k=StartGame();
	switch(k){
	case 0:
		goto exit;
		break;
	case 2:
		goto Rsave;
		break;
	}
ss:k=GamePlay(i,GQ,speed,IQ,c);
   switch(k){
   case 0:
	   goto exit;
	   break;
   case 2:
	   goto Rsave;
	   break;
   }
exit:return(1);

	 /*��ȡ��Ϸstart*/
Rsave:char ir[20];
	char GQr[20];
	char speedr[20];
	char IQr[20];
	gam_FILE *File;
	File=gam_fopen(GameName,'r');
	if(File==NULL){
		Cls();
		GuiMsgBox(filena[3],0);
		goto ss;
	}
	gam_fread(ir,20,1,File);
	gam_fread(GQr,20,2,File);
	gam_fread(speedr,20,3,File);
	gam_fread(IQr,20,4,File);
	i=atoi(ir)-1;
	GQ=atoi(GQr);
	speed=atoi(speedr);
	IQ=atoi(IQr);
	gam_fclose(File);
	GuiMsgBox(filena[2],0);
	c=1;
	goto ss;
	/*��ȡ��Ϸend*/

}