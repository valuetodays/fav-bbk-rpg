#include "basic.h"
#include "inc\fsys.h"

extern U8 *startword[5],*helpword[25];
extern U8 OcPicture[],MainPicture[];
extern U8 *name[4],*Gk[21],*Gks[12];
extern U8 *other,*rightw,*wrongw,*highhand,*state[7],*stateword[5],*GameName;
extern U8 *filena[4];

FAR void Sheep(int x,int y){
	SysCircle(x,y-5,10);
	SysCircle(x-5,y-15,5);
	SysRect(x+10,y-5,x+12,y+4);
	return;
}

FAR void Horse(int x,int y){
	SysCircle(x,y-5,11);
	SysCircle(x-5,y-15,5);
	SysRect(x+11,y-5,x+13,y+4);
	return;
}

FAR void Deer(int x,int y){
	SysCircle(x,y-5,9);
	SysCircle(x-5,y-15,5);
	SysRect(x+9,y-5,x+11,y+4);
	return;
}



FAR void Help2(){
	Cls();
	Sheep(80,25);
	Horse(30,65);
	Deer(128,65);
	SysPrintString(67,35,name[1]);
	SysPrintString(15,75,name[2]);
	SysPrintString(113,75,name[3]);
	Paused();
	Cls();
	return;
}

FAR void SheepHelp(){
	int j=1;
	MsgType key;
shelp_0:Cls();
	SysPrintString(0,0,helpword[j]);
	SysPrintString(0,16,helpword[j+1]);
	SysPrintString(0,32,helpword[j+2]);
	SysPrintString(0,48,helpword[j+3]);
	SysPrintString(0,64,helpword[j+4]);
	SysPrintString(0,80,helpword[j+5]);
shelp_1:GuiSetKbdType(SYS_ENG_KBD);
	GuiGetMsg(&key);
	GuiTranslateMsg(&key);
	if(key.type==WM_CHAR_FUN){
		if(key.param==CHAR_UP){
			j--;
			goto shelp_2;
		}
		else if(key.param==CHAR_DOWN){
			j++;
			goto shelp_2;
		}
		else if(key.param==CHAR_PGUP){
			j-=6;
			goto shelp_2;
		}
		else if(key.param==CHAR_PGDN){
			j+=6;
			goto shelp_2;
		}
		else if(key.param==CHAR_ENTER || key.param==CHAR_EXIT){
			Help2();
			return;
		}
	}
	goto shelp_1;
shelp_2:if(j<1){
			j=1;
		}
		else if(j>19){
			j=19;
		}
		goto shelp_0;
}


int StartGame(){
	int ia=1;
	MsgType key;
	Cls();
sp_0:SysPicture(0,0,158,95,OcPicture,0);
sp_1:SysPrintString(20,20,startword[ia]);
shp:GuiSetKbdType(SYS_ENG_KBD);
	GuiGetMsg(&key);
	GuiTranslateMsg(&key);
	if(key.type==WM_CHAR_FUN){
		if(key.param==CHAR_UP){
			ia--;
			goto pd;
		}
		else if(key.param==CHAR_DOWN){
			ia++;
			goto pd;
		}
		else if(key.param==CHAR_EXIT){
			return 0;
		}
		else if(key.param==CHAR_ENTER){
			switch(ia){
			case 4:
				SysPicture(0,0,158,95,MainPicture,0);
				Paused();
				goto sp_0;
				break;
			case 3:
				SheepHelp();
				goto sp_0;
				break;
			case 2:
				return 2;
				break;
			case 1:
				return 1;
				break;
			default:
				goto shp;
			}
		}
	}
	goto shp;
pd:if(ia<1){
	   ia=1;
   }
   else if(ia>4){
	   ia=4;
   }
   goto sp_1;
}

FAR int FunctionGP(int GQ,int speed,int i,int open){
	int sum=0;
	int pm;
	GuiMsgBox(Gks[GQ],0);
	RandEnvType Srnd;
	int k=0;
	int sheep_x,sheep_y;
	int sheep_num[20+i*5];
vs2:k++;
	sheep_num[k]=SysRand(&Srnd)%3;
	if(k<20+i*5){
		goto vs2;
	}
	k=1;
	sheep_y=SysRand(&Srnd)%60+20;
	sheep_x=140;
	Cls();
	if(sheep_num[k]==0){
		Sheep(sheep_x,sheep_y);
		sum++;
	}/*�����*/
	else if(sheep_num[k]==1){
		Horse(sheep_x,sheep_y);
	}/*�����*/
	else if(sheep_num[k]==2){
		Deer(sheep_x,sheep_y);
	}/*���¹*/
	pm=DelayFalseButExit(300-speed*5-i*20);
	if(pm==1){
		return 1;
	}
spd2:SysIconAllClear();
	k++;
	Cls();
	sheep_x-=40;
	if(sheep_x<30){
		sheep_x=20;
	}
	if(k==2)
	{
		if(sheep_num[k-1]==0){
		Sheep(sheep_x,sheep_y);
		sum++;
		}/*�����*/
	else if(sheep_num[k-1]==1){
		Horse(sheep_x,sheep_y);
	}/*�����*/
	else if(sheep_num[k-1]==2){
		Deer(sheep_x,sheep_y);
	}/*���¹*/
	    if(sheep_num[k]==0){
		Sheep(sheep_x+40,sheep_y);
		sum++;
		}/*�����*/
	else if(sheep_num[k]==1){
		Horse(sheep_x+40,sheep_y);
	}/*�����*/
	else if(sheep_num[k]==2){
		Deer(sheep_x+40,sheep_y);
	}/*���¹*/
	}
	else if(k==3)
	{
	  if(sheep_num[k-2]==0){
		Sheep(sheep_x,sheep_y);
		sum++;
		}/*�����*/
	    else if(sheep_num[k-2]==1){
			Horse(sheep_x,sheep_y);
		}/*�����*/
		else if(sheep_num[k-2]==2){
		Deer(sheep_x,sheep_y);
		}/*���¹*/
      if(sheep_num[k-1]==0){
		Sheep(sheep_x+40,sheep_y);
		sum++;
		}/*�����*/
	    else if(sheep_num[k-1]==1){
		Horse(sheep_x+40,sheep_y);
		}/*�����*/
		else if(sheep_num[k-1]==2){
		Deer(sheep_x+40,sheep_y);
		}/*���¹*/
	  if(sheep_num[k]==0){
		Sheep(sheep_x+80,sheep_y);
		sum++;
		}/*�����*/
	    else if(sheep_num[k]==1){
		Horse(sheep_x+80,sheep_y);
		}/*�����*/
		else if(sheep_num[k]==2){
		Deer(sheep_x+80,sheep_y);
		}/*���¹*/
	}
	else if(k>3)
	{
      if(sheep_num[k-3]==0){
		Sheep(sheep_x,sheep_y);
		sum++;
		}/*�����*/
	    else if(sheep_num[k-3]==1){
			Horse(sheep_x,sheep_y);
		}/*�����*/
		else if(sheep_num[k-3]==2){
		Deer(sheep_x,sheep_y);
		}/*���¹*/
      if(sheep_num[k-2]==0){
		Sheep(sheep_x+40,sheep_y);
		sum++;
		}/*�����*/
	    else if(sheep_num[k-2]==1){
		Horse(sheep_x+40,sheep_y);
		}/*�����*/
		else if(sheep_num[k-2]==2){
		Deer(sheep_x+40,sheep_y);
		}/*���¹*/
	  if(sheep_num[k-1]==0){
		Sheep(sheep_x+80,sheep_y);
		sum++;
		}/*�����*/
	    else if(sheep_num[k-3]==1){
		Horse(sheep_x+80,sheep_y);
		}/*�����*/
		else if(sheep_num[k-3]==2){
		Deer(sheep_x+80,sheep_y);
		}/*���¹*/
	  if(sheep_num[k]==0){
		Sheep(sheep_x+120,sheep_y);
		sum++;
		}/*�����*/
	    else if(sheep_num[k]==1){
		Horse(sheep_x+120,sheep_y);
		}/*�����*/
		else if(sheep_num[k]==2){
		Deer(sheep_x+120,sheep_y);
		}/*���¹*/
	}
	if(open==1){
		char sta[20];
		itoa(sum,sta,10);
		SysPrintString(0,0,sta);
	}
	pm=DelayFalseButExit(300-speed*5-i*20);
	if(pm==1){
		return 1;
	}
	if(k>19+i*5){
		return sum;
	}
	goto spd2;

	
}

void SaveR(int i,int GQ,int speed,int IQ)
{
	gam_FILE *File;
	char ir[20];
	char GQr[20];
	char speedr[20];
	char IQr[20];
	itoa(i,ir,10);
	itoa(GQ,GQr,10);
	itoa(speed,speedr,10);
	itoa(IQ,IQr,10);
	File=gam_fopen(GameName,'w');
	gam_fwrite(ir,20,1,File);
	gam_fwrite(GQr,20,2,File);
	gam_fwrite(speedr,20,3,File);
	gam_fwrite(IQr,20,4,File);
	gam_fclose(File);
	Cls();
	GuiMsgBox(filena[1],0);
}

FAR void State(int i,int GQ,int speed,int IQ)
{
	Cls();
	SysPicture(0,0,158,95,OcPicture,0);
	SysPrintString(5,0,stateword[1]);
	SysPrintString(5,18,stateword[2]);
	SysPrintString(5,36,stateword[3]);
	SysPrintString(5,54,stateword[4]);
	char istr[20];
	char GQstr[20];
	char speedstr[20];
	char IQstr[20];
	itoa(i,istr,10);
	itoa(GQ,GQstr,10);
	itoa(speed,speedstr,10);
	itoa(IQ,IQstr,10);
	SysPrintString(80,0,istr);
	SysPrintString(80,18,GQstr);
	SysPrintString(80,36,speedstr);
	SysPrintString(80,54,IQstr);
	Paused();
	return;
}

FAR int GamePlay(int i,int GQ,int speed,int IQ,int c)
{
	int sum;
	int open=0;
	int k=1;
	char forsum[20];
	MsgType key;
	SysPicture(0,0,158,95,OcPicture,0);
	i++;
	if(c==1){
		goto cs000;
	}
cs0:GuiMsgBox(Gk[i],0);
	sum=FunctionGP(GQ,speed,i,open);
	if(sum==1){
		return 0;
	}
cs_0:SysPicture(0,0,158,95,OcPicture,0);
	SysPrintString(5,30,other);
	itoa(k,forsum,10);
	SysPrintString(85,30,forsum);
cs_1:GuiSetKbdType(SYS_ENG_KBD);
	GuiGetMsg(&key);
	GuiTranslateMsg(&key);
	if(key.type==WM_CHAR_FUN){
		if(key.param==CHAR_UP){
			k++;
			goto cs_2;
		}
		else if(key.param==CHAR_DOWN){
			k--;
			goto cs_2;
		}
		else if(key.param==CHAR_PGUP){
			k+=10;
			goto cs_2;
		}
		else if(key.param==CHAR_PGDN){
			k-=10;
			goto cs_2;
		}
		else if(key.param==CHAR_EXIT){
			return 0;
		}
		else if(key.param==CHAR_ENTER){
			goto pdkabx;
		}
	}
	goto cs_1;
cs_2:if(k<1){
		 k=1;
	 }
	 else if(k>999){
		 k=999;
	 }
	 goto cs_0;
pdkabx:if(k==sum){
		   Cls();
		   GuiMsgBox(rightw,0);
		   Paused();
		   IQ+=10*i+GQ;
		   GQ++;
	   }
	   else{
		   Cls();
		   GuiMsgBox(wrongw,0);
		   Paused();
		   IQ+=1;
		   GQ++;
	   }
	   speed=GQ;
	   if(GQ>11){
		   GQ=1;
		   i++;
	   }
	   if(i>10){
		   Cls();
		   GuiMsgBox(highhand,0);
		   return 0;
	   }
cs000:int Numb=1;
cs00:SysPicture(0,0,158,95,OcPicture,0);
cs1:SysPrintString(20,20,state[Numb]);
cs_3:GuiSetKbdType(SYS_ENG_KBD);
	   GuiGetMsg(&key);
	   GuiTranslateMsg(&key);
	   if(key.type==WM_CHAR_FUN){
		   if(key.param==CHAR_UP){
			   Numb--;
			   goto cs_5;
		   }
		   else if(key.param==CHAR_DOWN){
			   Numb++;
			   goto cs_5;
		   }
		   else if(key.param==CHAR_ENTER){
			   goto cs_4;
		   }
		   else if(key.param==CHAR_HELP){
			open=1;
			goto cs_3;
		}
	   }
	   goto cs_3;
cs_4:switch(Numb){
		 case 1:
			 goto cs0;
			 break;
		 case 2:
			 State(i,GQ,speed,IQ);
			 goto cs00;
			 break;
		 case 3:
			 SaveR(i,GQ,speed,IQ);
			 goto cs00;
			 break;
		 case 4:
			 return 2;
			 break;
		 case 5:
			 SheepHelp();
			 goto cs00;
			 break;
		 case 6:
			 return 0;
			 break;
		 default:
			 goto cs_3;
	 }

cs_5:if(Numb<1){
		 Numb=1;
	 }
	 else if(Numb>6){
		 Numb=6;
	 }
	 goto cs1;

}


