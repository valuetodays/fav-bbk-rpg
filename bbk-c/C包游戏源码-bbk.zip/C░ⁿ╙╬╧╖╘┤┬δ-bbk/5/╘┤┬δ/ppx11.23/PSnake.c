#include "inc\dictsys.h"
#include "inc\keytable.h"
#include "PSnake.h"
extern U8 o2[];
extern U8 numpic[][9];
extern U8 gameover[];
extern U8 win[];
extern U8 whitelogo[];
extern U8 presskey[];
extern U8 choicemenu[];
extern U8 hero[][32];
extern U8 nandutiao[];
extern U8 *readme[12];
extern U8 daoju_pic[][32];
extern U8 touxiang[];
extern U8 defen_pic[];
extern U8 selectgame_pic[];
extern U8 icon[];
extern U8 ppx[];
extern U8 presskeytiao[];

/**********��Ҫ������и�ֵ����ı���************/
U8 x[20];		/*Բ��X*/
U8 y[20];		/*Բ��Y*/
U8 ax;		/*����x����*/
char cy;		/*��������ľ���*/
char rl[20];		/*��¼Բ�˶����ϻ��±���*/
char du[20];		/*��¼Բ�˶�������ұ���*/
U8 center[20];	/*Բ�뾶*/
/***********************************************/
U8 step;	/*����Ų�*/
U8 number;	/*Բ�ĸ���*/
U8 gtime;	/*��Ϸʱ��*/
U8 haveline;
U8 linetime;
U8 ly;
U8 lx;
U8 o;			/*��Բ��ʱ�����*/
U8 l;			/*��Ϸʱ���ʱ�����*/
U8 steptime;	/*��ɫ���߼�ʱ��*/
char face;		/*��ɫ����*/
U8 nowface;
char i,p,k,h,g,j;	/*��ʱ��������*/
U8 baodaoju,daoju_x,daoju_y;/*������ر���*/
U8 drawdaoju_time;
U8 daoju;
U16 gamepoint;/*��Ϸ�÷ֱ���*/
U8 live;	/*��*/
U16 jiansutime;/*���ٵ���ʱ��*/
U16 fangyutime;/*��������ʱ��*/
U8 Gamespeed;/*��Ϸ�ٶ�*/









FAR int GameTanShiShe()
{
GuiInit();
SysMemInit(MEM_HEAP_START,MEM_HEAP_SIZE);
GuiSetInputFilter(!INPUT_ALL_ENABLE);
RandEnvType srnd;
SysSrand(&srnd,SysGetSecond(),200);
NewStart:
GameInit();

if(showlogo()==10)
goto over;
if(Game_lianxi_Menu()==10)
goto over;

GameON();
goto NewStart;

over:
return(1);
}



















/***********************************************************************
 * ������:	GameON()
 * ˵��:		��Ϸ������������
 * �������:	�� 
 * ����ֵ  :	��
***********************************************************************/
FAR void GameON()
{
MsgType msg;
ShowGameface();
SysTimer1Open(1);
while(1)
{
	
	
	if(fangyutime>0)
	if(fangyutime%100==0)
	shownum(4,18,fangyutime/100);
	

GuiGetMsg(&msg);
if(msg.type==WM_KEY)
  if(msg.param==KEY_Q)
  {
  haveline++;
  if(haveline==1)
  if(nowface==2)
  lx=ax;
  else
  lx=ax+15;				
  }
GuiTranslateMsg(&msg);
	if(msg.type==WM_TIMER)
	{	
	o++;
	l++;
	steptime++;	
		if(haveline>0)
		linetime++;
		if(daoju>0)
		drawdaoju_time++;
	daojuchuli();
	
	BallON();
	if(cy<center[p])
	goto died;
	
	LineON();
	if(number<1)
	goto died;
	
	TimeON();
	if(gtime<1)
	goto died;
	
	StepON();
	
	Drawdaoju();
	}
/***************************���������*******************************************/
	else
	{
		if(msg.type==WM_CHAR_FUN)
		{
			if(msg.param==CHAR_LEFT){/*����������*/
			face=2;
			nowface=2;
			}
			else if(msg.param==CHAR_RIGHT){/*��������Ҽ�*/
			face=1;
			nowface=1;
			}
			else if(msg.param==CHAR_DOWN)
			face=0;
			else if(msg.param==CHAR_ENTER)
			{
			haveline++;
			if(haveline==1)
			if(nowface==2)
			lx=ax;
			else
			lx=ax+15;				
			}			
		}
	}
}
/*******************************************************************************/
died:
SysTimer1Close();
if(number<1)
{
SysPicture(27,34,130,53,win,0);
k=gtime;
	for(;1<k;k--)
	{
		for(fangyutime=0;fangyutime<5000;fangyutime++)
		i=0;
		l=201;
	TimeON();
	gamepoint+=10;
	shownum(87,4,gamepoint);
	}

}
else
SysPicture(27,34,126,53,gameover,0);
while(1){
GuiGetMsg(&msg);
	GuiTranslateMsg(&msg);
	if(msg.type==WM_CHAR_FUN){
		if(msg.param==CHAR_EXIT)
		break;
		}
	}
}

/***********************************************************************
 * ������:	GameInit()
 * ˵��:		��Ϸ��ʼ��
 * �������:	�� 
 * ����ֵ  :	��
***********************************************************************/
FAR void GameInit()
{
int z;
for(z=0;z<30;z++){center[z]=0;x[z]=0;y[z]=0;rl[z]=0;du[z]=0;}
number=0;
ly=0;lx=0;
o=0;l=0;i=0;p=0;j=0;h=0;g=0;
steptime=0;face=0;nowface=0;ax=0;
baodaoju=0;daoju_x=0;daoju_y=0;drawdaoju_time=0;daoju=0;
jiansutime=0;fangyutime=0;
Gamespeed=0;
gtime=76;
i=0;
o=0;
step=1;
face=0;
steptime=0;
ax=0;
ax=2;
gtime=76;
l=0;
haveline=0;
ly=80;
lx=0;
linetime=0;
gamepoint=0;/*��Ϸ�÷�*/
cy=100;
Gamespeed=5;
daoju=0;
live=3;
}

/***********************************************************************
 * ������:	FAR void daojuchuli()
 * ˵��:		��Ϸ���ߴ���
 * �������:	�� 
 * ����ֵ  :	��
***********************************************************************/
FAR void daojuchuli()
{
		if(fangyutime>0){
		fangyutime--;
		if(fangyutime==0){
		SysLcdPartClear(3,18,19,34);		
		SysLcdPartClear(3,76,147,94);
		SysPicture(ax,79,ax+15,94,hero[1],0);
		}
		}
		
		if(jiansutime>0)
		{
			if(jiansutime==500)
			Gamespeed*=3;
		jiansutime--;
		if(jiansutime==1)
		Gamespeed=5;
		}
}

/***********************************************************************
 * ������:	FAR void BallON()
 * ˵��:		���˶�����
 * �������:	�� 
 * ����ֵ  :	��
***********************************************************************/

FAR void BallON()
{
/*SysTimer1Close();*/
if(o>Gamespeed)	/*ʱ�䵽��ʼ����*/
		{
			o=0;
			for(p=0;p<number;p++)
			{
			/**********���������******/
			if(abs((int)ax+8-(int)x[p])<(int)center[p]+8)
			if(abs(79-(int)y[p])<(int)center[p]+8)
			{
			cy=(char)( sqrt(  kcf( (int)x[p] - (int)ax -8 )  +  kcf(87-(int)y[p])  ) )-7;
				/***************������****************/				
				if(fangyutime>0)
				{
				cy=100;
					if(face==0)
					{
						if(nowface==1)
						SysPicture(ax,79,ax+15,94,hero[1],0);
						if(nowface==2)
						SysPicture(ax,79,ax+15,94,hero[3],0);
						SysRect(ax,77,ax+15,94);
					}
				}
				else if(cy<center[p])
				return;
				/****************************************/	
			}
			/****************************/
			SysCircleClear(x[p],y[p],center[p]);
			x[p]+=rl[p];
			y[p]+=du[p];
			SysCircle(x[p],y[p],center[p]);
				if(y[p]>93-center[p])
				du[p]=-1;
				else if(y[p]<center[p]+18)
				du[p]=1;
				else if(x[p]<center[p]+4)
				rl[p]=1;
				else if(x[p]>147-center[p])
				rl[p]=-1;
			}
		}
/*SysTimer1Open(1);*/
}
/***********************************************************************
 * ������:	TimeON()
 * ˵��:		��Ϸʱ�䴦��----ʱ����
 * �������:	�� 
 * ����ֵ  :	��
***********************************************************************/
FAR void TimeON()
{
		if(l>200)
		{
		l=0;
		gtime--;
		if(gtime<1)
		return;
		SysLineClear(155,93-gtime,156,93-gtime);/*��ʱ����*/
		}	
}
/***********************************************************************
 * ������:	LineON()
 * ˵��:		�����ߴ���
 * �������:	�� 
 * ����ֵ  :	��
***********************************************************************/
FAR void LineON()
{
SysTimer1Close();
RandEnvType srnd2;
if(linetime>5)
	{
	linetime=0;
		if(haveline>1)	 /*������˵�2�ι����򽫵�һ�λ�����������������������¸�ֵ*/	
		{
		SysLineClear(lx,ly,lx,94);
		ly=80;
			if(nowface==2)
			lx=ax;
			else
			lx=ax+15;
		haveline=1;
		}
		else
		{
		ly--;
		SysLine(lx,ly,lx,94);
				if(ly<27){  /*������Ѿ��������˻�����Ϊ�㡰��ֹͣ���߲��������*/
				SysLineClear(lx,ly,lx,94);
				ly=80;
				haveline=0;
				}
		}
		for(h=0;h<number;++h)
		{
			if(abs((int)x[h]-(int)lx)<center[h])
			{
				if(abs((int)y[h]-(int)ly)<center[h] | y[h]>ly)
				{
				gamepoint+=100;
				shownum(87,4,gamepoint);
				SysCircleClear(x[h],y[h],center[h]);
					if(baodaoju==120){
					gamepoint+=1000;
					shownum(87,4,gamepoint);
					baodaoju==0;					
					center[h]=0;
					}
					else
					center[h]-=4;
						/***********�����Ƿ��������*****************/
						if(daoju==0)
						baodaoju=SysRand(&srnd2);
						if(baodaoju>120)
						{
								if(x[h]>126)
								daoju_x=126;
								else if(x[h]<2)
								daoju_x=x[h];
								else
								daoju_x=x[h];
								if(y[h]>78)
								daoju_y=78;
								else if(y[h]<17)
								daoju_y=17;
								else
								daoju_y=y[h];
						if(120<baodaoju)
						daoju=1;
						if(125<baodaoju)
						daoju=2;
						if(130<baodaoju)
						daoju=3;
						if(134<baodaoju)
						daoju=4;
						if(140<baodaoju)
						daoju=6;
						if(155<baodaoju)
						daoju=5;
						baodaoju=0;
						}
						/*************************************************/	
						if(center[h]<4)
						{
						number--;
						haveline=0;
						SysLineClear(lx,ly,lx,94);
						ly=80;
						j++;
						if(number<1)
						return;
							center[h]=center[number];
							rl[h]=rl[number];
							du[h]=du[number];
							x[h]=x[number];
							y[h]=y[number];											
						}
						else
						{
						center[number]=center[h];
						rl[number]=rl[h]*-1;
						du[number]=du[h];
						x[number]=x[h];
						y[number]=y[h];
						number++;
						haveline=0;
						SysLineClear(lx,ly,lx,94);
						ly=80;
						j++;
						}
				}
			}	
		if(j>0){
		j=0;
		break;}
		}
	}
SysTimer1Open(1);	
}

/***********************************************************************
 * ������:	void Drawdaoju()
 * ˵��:		��������
 * �������:	�� 
 * ����ֵ  :	��
***********************************************************************/
FAR void Drawdaoju()
{
  if(drawdaoju_time>6)
  {
  drawdaoju_time=0;
	if(daoju_y>77)
	SysPicture(daoju_x,78,daoju_x+15,93,daoju_pic[daoju],0);
	else
	{
	daoju_y++;
	SysPicture(daoju_x,daoju_y,daoju_x+15,daoju_y+15,daoju_pic[daoju],0);
	}
  }
}
/***********************************************************************
 * ������:	void StepON()
 * ˵��:		������������
 * �������:	�� 
 * ����ֵ  :	��
***********************************************************************/
FAR StepON()
{
	if(face>0)
	{
		if(steptime>3)
		{
		steptime=0;
		if(fangyutime>0)
		SysRectClear(ax,77,ax+15,94);
			if(face==2)
			{
			ax--;
				if(ax<2){ax=2;face=0;}
				if(step==2)
				{
				step=1;
				SysPicture(ax,79,ax+15,94,hero[3],0);
				}
				else{
				step=2;
				SysPicture(ax,79,ax+15,94,hero[2],0);
				}			
			}
			else if(face==1)
			{
			ax++;
				if(ax>135){ax=135;face=0;}		
				if(step==2){
				step=1;
				SysPicture(ax,79,ax+15,94,hero[1],0);
				}
				else{
				step=2;
				SysPicture(ax,79,ax+15,94,hero[0],0);
				}			
			}
			if(fangyutime>0){
			SysRect(ax,77,ax+15,94);}
		}	
	}

	if(daoju_y>62)
	if( (int)( abs((int)daoju_x+8-((int)ax+8)) ) -6 < 8 )
	{
			if(daoju==6)
			{
			gtime+=10;
			if(gtime>76)
			gtime=76;
			SysFillRect(155,94-gtime,156,92);
			}

			if(daoju==1)
			fangyutime=900;

			if(daoju==2)
			jiansutime=500;

			if(daoju==5){
			gamepoint+=500;
			shownum(87,4,gamepoint);}

			if(daoju==3)
			wujiaoxing();

			if(daoju==4)
			baodaoju=120;

		SysLcdPartClear(daoju_x,daoju_y,daoju_x+15,daoju_y+15);
		daoju_x=0;daoju_y=0;drawdaoju_time=0;
		daoju=0;
	}
}
/*************************��Ϸ��ʼ�˵�LOGO**********************************/
/*U8 Game_lianxi_Menu();												*/
/******************************�޷���ֵ**************************************/
U8 Game_lianxi_Menu()
{
RandEnvType srnd2;
MsgType msg;
char face=0;
U8 steptime=0;
U8 step=1;
U8 ax=11;
go:
SysLCDClear();
SysPicture(1,1,158,72,choicemenu,0);
SysPicture(14,91,148,95,nandutiao,0);
SysPicture(ax,75,ax+15,90,hero[1],0);
SysTimer1Open(1);
  while(1)
  {
  GuiGetMsg(&msg);
  GuiTranslateMsg(&msg);
	if(msg.type==WM_TIMER)
	{
	steptime++;
		if(face>0)
		{
			if(steptime>3)
			{
			steptime=0;
				if(face==2)
				{
				ax--;
					if(ax<11){ax=11;face=0;}
					if(step==2)
					{
					step=1;
					SysPicture(ax,75,ax+15,90,hero[3],0);
					}
					else
					{
					step=2;
					SysPicture(ax,75,ax+15,90,hero[2],0);
					}
				}
				else if(face==1)
				{
				ax++;
				
					if(ax>135){ax=135;face=0;}		
					if(step==2){
					step=1;
					SysPicture(ax,75,ax+15,90,hero[1],0);
					}
					else{
					step=2;
					SysPicture(ax,75,ax+15,90,hero[0],0);
					}
				}
			}
		}	
	}
	else if(msg.type==WM_CHAR_FUN)
	{
		if(msg.param==CHAR_LEFT)/*����������*/
		face=2;
		else if(msg.param==CHAR_RIGHT)/*��������Ҽ�*/
		face=1;
		else if(msg.param==CHAR_DOWN)
		face=0;
		else if(msg.param==CHAR_ENTER)
		break;
		else if(msg.param==CHAR_HELP)
		{
		NowReadme();
		goto go;
		}
		else if(msg.param==CHAR_EXIT)
		return(10);
	}	
  }
 ax+=8;
  if(ax>14 && ax<31){
  center[0]=8;number=1;}
  else if(ax>31 && ax<39){
  center[0]=8;
  number=2;
  center[1]=12;}
  else if(ax>39 && ax<62){
  center[0]=12;number=1;}
  else if(ax>63 && ax<70){
  center[0]=12;number=2;
  center[1]=16;
  }
  else if(ax>70 && ax<101){
  center[0]=16;number=1;}
  else if(ax>101 && ax<109){
  center[0]=16;number=2;
  center[1]=20;
  }
  else if(ax>109){
  center[0]=20;
  number=1;}

x[0]=SysRand(&srnd2)%81+35;
y[0]=center[0]+20;
rl[0]=1;
du[0]=1;
x[1]=x[0];
y[1]=y[0];
rl[1]=-1;
du[1]=1;
}
/*************************SHOW��Ϸ��LOGO**********************************/
/*showlogo();														       */
/******************************�޷���ֵ**************************************/
U8 showlogo()
{
int j,h;
MsgType msg;
SysLCDClear();
SysPicture(5,73,155,95,presskeytiao,0);
for(j=71;j>1;j--){
for(h=0;h<1000;h++)
h=h;
SysPicture(1,j,158,71,whitelogo,0);
}
SysPicture(28,80,131,88,presskey,0);
SysTimer1Open(1);
U8 e=0;
/*int o,p;*/
U8 i;
i=1;
while(1)
{
GuiGetMsg(&msg);
GuiTranslateMsg(&msg);
	if(msg.type==WM_TIMER)
	{
	e++;
		if(e==50)
		SysLcdPartClear(28,80,131,88);
		else if(e==100)
		{
		SysPicture(28,80,131,88,presskey,0);
		e=0;		
		}
	}
	else if(msg.type==WM_CHAR_FUN){
		if(msg.param==CHAR_EXIT)
		return(10);
		else
		break;
		}
	else
	break;
}
SysTimer1Close();
}
/*************************README����****************************************/
/*NowReadme();												     	       */
/******************************�޷���ֵ**************************************/

void NowReadme()
{
	U8 a=1;
	MsgType key;
	ius:SysLCDClear();
	SysPrintString(0,0,readme[a]);
	SysPrintString(0,16,readme[a+1]);
	SysPrintString(0,32,readme[a+2]);
	SysPrintString(0,48,readme[a+3]);
	SysPrintString(0,64,readme[a+4]);
	SysPrintString(0,80,readme[a+5]);
key1:GuiSetKbdType(SYS_ENG_KBD);
while(1)
{
	GuiGetMsg(&key);
	GuiTranslateMsg(&key);
	if(key.type==WM_CHAR_FUN)
	{
		if(key.param==CHAR_DOWN){
			a+=1;
			goto pas1;
		}
		else if(key.param==CHAR_UP){
			a-=1;
			goto pas1;
		}
		else if(key.param==CHAR_PGUP){
			a-=6;
			goto pas1;
		}
		else if(key.param==CHAR_PGDN){
			a+=6;
			goto pas1;
		}
		else if(key.param==CHAR_EXIT){
			a=1;
			return;
		}
		goto key1;
	}
}	
pas1:if(a>6){
		 a=6;
	 }
	 else if(a<1){
		 a=1;
	 }
	 goto ius;
}

/*************************���������*********************************************/
/*void shownum(U8 x,U8 y,long num);*/										       
/******************************�޷���ֵ**************************************/
void shownum(U8 x,U8 y,long num)
{
U8 wei[7];
U8 weishu;
char a;
a=0;
weishu=0;
wei[1]=0;
wei[2]=0;
wei[3]=0;
wei[4]=0;
wei[5]=0;
wei[6]=0;
if(num>=100000)
weishu=6;
else if(num>=10000)
weishu=5;
else if(num>=1000)
weishu=4;
else if(num>=100)
weishu=3;
else if(num>=10)
weishu=2;
else if(num>=0)
weishu=1;
			if(num>=100000){
			wei[6]=(U8)((num-num%100000)/100000);
			num%=100000;				
			}
			if(num>=10000){
			wei[5]=(U8)((num-num%10000)/10000);
			num%=10000;	
			}
			if(num>=1000){
			wei[4]=(U8)((num-num%1000)/1000);
			num%=1000;
			}
			if(num>=100){
			wei[3]=(U8)((num-num%100)/100);
			num%=100;			
			}
			if(num>=10){
			wei[2]=(U8)((num-num%10)/10);
			num%=10;			
			}
			if(num>=0){
			wei[1]=(U8)(num);
			}
for(a=weishu;a>0;a--)
SysPicture(   (weishu-a)*8+x  ,  y  ,  (weishu-a)*8+x+7  ,  y+8   ,   numpic[ wei[a] ]  ,  0  );
}

/********************��Ϸ����**********************/
/*void ShowGameface();*/	
/***************************************************/
void ShowGameface()
{
SysLCDClear();
SysPicture(137,1,158,16,o2,0);
SysPicture(53,2,83,14,defen_pic,0);
SysPicture(1,1,48,14,ppx,0);
SysLine(17,6,22,11);
SysLine(17,11,22,6);
SysRect(1,15,151,95);/*���*/
SysRect(153,17,158,93);/*ʱ���*/
SysFillRect(155,18,156,92);/*ʱ������*/
shownum(87,4,gamepoint);
SysPicture(ax,79,ax+15,94,hero[1],0);
}






/*************************���η�*********************************************/
/*int kcf(int a);										       */
/******************************�޷���ֵ**************************************/
U16 kcf(int a)
{
a*=a;
return a;
}

/***********************************************************************
 * ˵��:     ��ȡһ��255���ڵ�ƽ����(����)
 * �������: num-����ֵ��ƽ��
 * ����ֵ  : ƽ����
***********************************************************************/
U8 sqrt(U16 num)
{
	U8	gen,step;
	U8	tcnt;
	
	gen = 0;
	step = 10;
	while(1)
	{
		if(!step) break;
		tcnt = gen + step;
		if((U16)tcnt * tcnt < num)
			gen = tcnt;
		else
			step -= 1;		
	}
	return gen;
}
/****************************�����ֵ****************************/
/*U16 abs(int a);*/	
/****************************************************************/
U16 abs(int a)
 {
 U16 b;
   b=(a>0)?a:(a*=-1);
   return b;
 }
 
 
 
 
 
 
 
 
FAR void wujiaoxing()
{
for(h=0;h<number;h++)
{
	SysCircleClear(x[h],y[h],center[h]);
	center[h]-=4;
		if(center[h]<4)
		center[h]=4;
		else
		{
		number++;					
		center[number-1]=center[h];
		rl[number-1]=rl[h]*-1;
		du[number-1]=du[h];
		x[number-1]=x[h];
		y[number-1]=y[h];
		ly=80;
		gamepoint+=100;
		shownum(87,4,gamepoint);
		}
	SysCircle(x[h],y[h],center[h]);
}
}