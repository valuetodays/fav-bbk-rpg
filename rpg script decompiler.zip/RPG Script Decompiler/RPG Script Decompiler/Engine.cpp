#include "StdAfx.h"
#include "Engine.h"

#include "TagResources.h"

int CEngine::GetType( void ) const
{
	return m_byType;
}

int CEngine::GetIndex( void ) const
{
	return m_byIndex;
}

int CEngine::GetLength( void ) const
{
	return m_wLength;
}

CEngine::CEngine( istream *sInStream)
{
	ASSERT(NULL != sInStream);

	m_InStream = sInStream;
	m_wJumpTable = NULL;
	m_bLabelFlags = NULL;
	m_strStream = new stringstream();

	m_byType = ReadByte();
	m_byIndex = ReadByte();

	sInStream->seekg(uBaseAddr);
	m_wLength = ReadWord();

	if (!FileIsValid(m_wLength))
	{
		throw "Input File was invalid!";
	}
}

CEngine::~CEngine( void )
{
	delete[] m_wJumpTable;
	m_wJumpTable = NULL;

	delete[] m_bLabelFlags;
	m_bLabelFlags = NULL;

	delete m_strStream;
	m_strStream = NULL;
}

stringstream * CEngine::GetOutStream( void )
{
	return m_strStream;
}

void CEngine::SetJumpTable( void )
{
	m_bLabelFlags = new bool[m_wLength];

	m_byJumpTableSize = ReadByte();
	m_wJumpTable = new word[m_byJumpTableSize];

	for (int i = m_byJumpTableSize * 2; i < m_wLength; i++)
	{
		m_bLabelFlags[i] = false;
	}

	word wTmp = 0;
	for (int i = 0; i < m_byJumpTableSize; i++)
	{
		wTmp = ReadWord();
		if (wTmp != 0)
		{
			if (wTmp < 5)
			{
				throw "Error JumpTable!";
			}
			SetLabelFlag(wTmp);
		}
		m_wJumpTable[i] = wTmp;
	}
}

CEngine::byte CEngine::ReadByte(void) const
{
	byte bTmp = 0;
	m_InStream->read(reinterpret_cast<char *>(&bTmp), sizeof(byte));
	return bTmp;
}

CEngine::word CEngine::ReadWord(void) const
{
	word wTmp = ReadByte();
	wTmp |= ReadByte() << 8;

	return wTmp;
}

CEngine::dword CEngine::ReadDword( void ) const
{
	dword wTmp = ReadWord();
	wTmp |= ReadWord() << 16;

	return wTmp;
}

const char * CEngine::FormatParam( const char *szParam )
{
	const char *szLabel = "label_";
	static char str[64 * 1024];
	*str = '\0';
	char *cParam = const_cast<char *>(szParam);

	// �ַ�����
	static char buf[10 * 1024];
	*buf = '\0';
	word wAddr = 0;
	char c = '\0';

	while((c = *cParam++) != '\0')
	{
		if (*str != '\0')
		{
			strcat_s(str, " ");
		}

		switch (c)
		{
			// ֱ�ӵ�ַ
		case 'A':
			wAddr = ReadWord();
			SetLabelFlag(wAddr);
			_itoa_s(wAddr, buf, 10);
			strcat_s(str, szLabel);
			strcat_s(str, buf);
			break;
			// �ַ���
		case 'C':
			strcat_s(str, "\"");
			do
			{
				m_InStream->getline(buf, sizeof(buf), '\0');
				strcat_s(str, buf);
			} while (!m_InStream && (strlen(buf) == (sizeof(buf) - 1)));
			strcat_s(str, "\"");
			break;
			// ��ӵ�ַ
		case 'E':
			wAddr = m_wJumpTable[ReadByte()];
			SetLabelFlag(wAddr);
			_itoa_s(wAddr, buf, 10);
			strcat_s(str, szLabel);
			strcat_s(str, buf);
			break;
			// 4�ֽ���
		case 'L':
			_itoa_s(ReadDword(), buf, 10);
			strcat_s(str, buf);
			break;
			// 2�ֽ���
		case 'N':
			_itoa_s(ReadWord(), buf, 10);
			strcat_s(str, buf);
			break;
			// ���N
		case 'U':
			_itoa_s(ReadWord(), buf, 10);
			*str = '\"';
			strcat_s(str, buf);
			while (m_InStream->peek() != 0)
			{
				_itoa_s(ReadWord(), buf, 10);
				strcat_s(str, " ");
				strcat_s(str, buf);
			}
			strcat_s(str, "\"");
			m_InStream->seekg(1, fstream::cur);
			break;
		}
	}

	return str;
}

void CEngine::SetLabelFlag( word wIndex)
{
	if (wIndex >= m_wLength)
	{
		throw "Error Label Address!";
	}
	m_bLabelFlags[wIndex] = true;
}

const char * CEngine::GetTagName( byte iIndex) const
{
	if (iIndex >= CCommand::END)
	{
		throw "Unknown Command!";
	}
	return TAG_TEXT[iIndex];
}

const char * CEngine::GetTagParam( byte iIndex ) const
{
	if (iIndex >= CCommand::END)
	{
		throw "Unknown Command!";
	}
	return TAG_PARAM[iIndex];
}

bool CEngine::Process( void )
{
	bool bResult = false;

	try
	{
		SetJumpTable();

#pragma region ���ʱ�������Ϣ
		time_t tCurTime = time(NULL);
		char *cTmp = new char[128];
		ctime_s(cTmp, 128, &tCurTime);
		*m_strStream << "@ This file was decompiled by RPG Script Decomplier!" << endl
			<< "@ Datetime:\t" << cTmp << endl << endl;
		delete[] cTmp;
		cTmp = NULL;
#pragma endregion ���ʱ�������Ϣ

		auto_ptr<list<CCommand>> lCommands(new list<CCommand>());
		auto_ptr<CCommand> cmCur(NULL);
		char buf[64 * 1024];
		byte byCur = 0;

#pragma region ָ�����
		while(byCur = ReadByte(), !m_InStream->eof())
		{
			// ��ǰλ��
			word wCurAddr = static_cast<word>(m_InStream->tellg()) - uBaseAddr - 1;

			cmCur.reset(new CCommand());
			cmCur->SetAddress(wCurAddr);

			strcpy_s(buf, GetTagName(byCur));
			// �Ű��Ż�
			if (byCur == CCommand::Callback || byCur == CCommand::Return)
			{
				strcat_s(buf, "\n");
			}

			// �Ƿ��в���
			const char *szParam = GetTagParam(byCur);
			if (*szParam != '\0')
			{
				strcat_s(buf, " ");
				strcat_s(buf, FormatParam(szParam));
			}

			cmCur->SetText(buf);

			lCommands->push_back(*cmCur.release());
		}
#pragma endregion ָ�����

#pragma region ���
		for_each(lCommands->begin(), lCommands->end(), [&](CCommand &element)
		{
			word wAddr = element.GetAddress();
			if (m_bLabelFlags[wAddr])
			{
				*m_strStream << endl
					<< "label_" << wAddr << ":" << endl;
			}

			*m_strStream << element.GetText() << endl;
		});

		*m_strStream << endl;
#pragma endregion ���

#pragma region ��� GutEvent ����
		if (m_byJumpTableSize > 0)
		{
			*m_strStream << "@======GutEvent======" << endl;
		}

		for (int i = 0; i < m_byJumpTableSize; i++)
		{
			word wTmp = m_wJumpTable[i];
			if (wTmp != 0)
			{
				*m_strStream << GetTagName(CCommand::GutEvent) << " " << i + 1 << " label_" << wTmp << endl;
			}
		}
#pragma endregion ��� GutEvent ����

		bResult = true;
	}
	catch(const char *szMsg)
	{
		cerr << szMsg << endl
			<< "Decompiler fail!" << endl;
	}

	return bResult;
}

bool CEngine::FileIsValid( int iGutSize )
{
	fpos<int> pCurPost = m_InStream->tellg();

	m_InStream->seekg(0, istream::end);
	fpos<int> pFileSize = m_InStream->tellg();

	if (pFileSize == static_cast<fpos<int>>(iGutSize + uBaseAddr))
	{
		m_InStream->seekg(pCurPost, istream::beg);
		return true;
	}
	else
	{
		return false;
	}

}

#pragma region class CCommand ����
CEngine::CCommand::CCommand()
{
	this->m_wAddr = -1;
	this->m_szText = NULL;
}

CEngine::CCommand::CCommand( const CCommand &right )
{
	this->m_wAddr = right.m_wAddr;
	const char *szText = right.GetText();
	if (NULL == szText)
	{
		this->m_szText = NULL;
	}
	else
	{
		this->SetText(szText);
	}
}

CEngine::CCommand::~CCommand()
{
	delete[] m_szText;
	m_szText = NULL;
}

void CEngine::CCommand::SetText( const char * szText )
{
	size_t length = strlen(szText) + 1;
	m_szText = new char[length];
	strcpy_s(m_szText, length, szText);
}

const char * CEngine::CCommand::GetText( void ) const
{
	return m_szText;
}

void CEngine::CCommand::SetAddress( const word & wAddr )
{
	m_wAddr = wAddr;
}

CEngine::word CEngine::CCommand::GetAddress( void ) const
{
	return m_wAddr;
}

CEngine::CCommand & CEngine::CCommand::operator = ( const CCommand &right )
{
	if (this == &right)
	{
		return *this;
	}
	else
	{
		this->m_wAddr = right.m_wAddr;

		delete[] m_szText;
		const char *szText = right.GetText();
		if (NULL == szText)
		{
			this->m_szText = NULL;
		}
		else
		{
			this->SetText(szText);
		}
	}

	return *this;
}
#pragma endregion class CCommand ����
