#include "cvm.h"

#define aslkdjfalsdfkj 30

const char *s;
short i,*b,d[aslkdjfalsdfkj];

short main1(int a,int b)
{
	if (a > b)
		return(a);
	else
		return(b);
}

int main()
{
	int i, j, ext;
	extern char ss[60];
	typedef FILE FILETYPE;
	FILETYPE *fp;
	
	/*if (NULL == (fp = fopen("test.txt", "wb")))
	{
		puts("cann't open test.txt\n");
	}
	else
	{
		fwrite("test file io.", 13, 1, fp);
		fclose(fp);
	}*/
	
	/*i = 1;
	j = 2;
	ext = main1(i,j);
	if (ext == i)
		*ss = 'i';
	else
		*ss = 'j';
	
	putchar(*ss);*/
	/*free("loop strat\n");*/
	for (i = 0;i < 100;i++)
	{
		/*puts("alsdjfalsj\ndlk\tfjalsjd");*/
		for (j = 0;j < 100;j++)
		{
		}
	}
	
	do
	{
		gets(ss);
		switch (ss[0])
		{
		case '8':
			switch (ss[1])
			{
			case '8':
				puts("get 88");
				break;
			case '9':
				puts("get 89");
				break;
			default:
				puts("get 8");
			}
		case 'E':
			puts("get E");
			break;
		}
			
	}
	while (strcmp(ss, "EXIT"));
	
	/*do
	{
		gets(ss);
	}
	while (strcmp(ss, "EXIT"));*/
	/*isalnum(i);
	free("loop end\n");
	isalnum(j);*/
	/*puts("alsdjfalsj\ndlk\tfjalsjd");
	puts(ss);*/
	/*while (1);*/
}
