package hz.cdj.game.fmj.goods;

import hz.cdj.game.fmj.characters.Player;

public interface IEatMedicine {
	void eat(Player player);
}
