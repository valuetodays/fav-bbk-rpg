#include "inc\dictsys.h"
#include "inc\keytable.h"
#include "inc\stdlib.h"
#include "inc\flash.h"


FAR void Paused()
{
	MsgType key;
	GuiGetMsg(&key);
	return;
}
FAR void Cls()
{
	SysLCDClear();
	return;
}
FAR void Maind()
{
	GuiInit();	/*Gui OS ��ʼ����ʹ��ǰһ��Ҫ���� */
	SysMemInit(MEM_HEAP_START,MEM_HEAP_SIZE);	/*��ʼ����*/
	return;
}
FAR void DelayTrue(int DN)/*��ʱ�������˳�*/
{
	int TN=SysGetTimer1Number();
	MsgType key;
	SysTimer1Close();
	SysTimer1Open(1);
	while(DN>0)   /*��ʱδ��*/
	{
		GuiGetMsg(&key);
		GuiTranslateMsg(&key);
		if(key.type!=WM_TIMER)   /*�а���*/
			break;
		DN-=1;
	}
	SysTimer1Close();
	SysTimer1Open(TN);
	return;
}
FAR void DelayFalse(int DN)
{
	int TN=SysGetTimer1Number();
	MsgType key;
	SysTimer1Close();
	SysTimer1Open(1);
	while(DN>0)   /*��ʱδ��*/
	{
		GuiGetMsg(&key);
		GuiTranslateMsg(&key);
		DN-=1;
	}
	SysTimer1Close();
	SysTimer1Open(TN);
	return;
}

int DelayFalseButExit(int DN)
{
GO:	int TN=SysGetTimer1Number();
	MsgType key;
	SysTimer1Close();
	SysTimer1Open(1);
	while(DN>0)   /*��ʱδ��*/
	{
		GuiGetMsg(&key);
		GuiTranslateMsg(&key);
		if(key.type!=WM_TIMER && key.param==CHAR_EXIT){
			SysTimer1Close();
			SysTimer1Open(TN);
			return 1;
		}
		DN-=1;
	}
	SysTimer1Close();
	SysTimer1Open(TN);
	goto GO;
}