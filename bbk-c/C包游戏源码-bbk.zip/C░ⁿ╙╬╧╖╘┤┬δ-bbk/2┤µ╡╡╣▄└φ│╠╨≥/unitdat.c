#include "filedeal.h"
#include "tran.h"


TranType pTran;
U8 tranbuf[255];
U8 readbuf[150];
U8 writebuf[150];

U8 notestring[40];

U16 listtop;
U16 listset;
U16 listlen;

U16 fnames[LISTSHOWMAX];

U8	fpInf[12];
U16	flen;


U8 tranendflag;
U16 doff;
FileInf fileinf;
TranFileType filetran;
U8 *g_filedata;

