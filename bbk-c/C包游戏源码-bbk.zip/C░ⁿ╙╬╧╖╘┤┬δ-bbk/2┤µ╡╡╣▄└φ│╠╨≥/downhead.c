#include	"inc\dictsys.h"
#include 	"inc\stdlib.h"
#include	"inc\shell.h"
#include	"inc\filetype.h"
#if	GAM_PHY_SET==3980
#define	DICT_VER	0x30
#else
#if	GAM_PHY_SET==3680
#define	DICT_VER	0x60
#else
#if	GAM_PHY_SET==3288
#define	DICT_VER	0x22
#else
#if	GAM_PHY_SET==6980
#define	DICT_VER	0x21
#else
#define	DICT_VER	0x10
#endif
#endif
#endif
#endif


extern	U16		FileDeal;

const	TypeDownAppHead		downAppHead = 
{
	{
		FT_GAME,
		DICT_VER,
		"�浵����",
		STR_CORP_NAME,
		TRUE,
		""
	},
	FileDeal,
	0x8000,
};

