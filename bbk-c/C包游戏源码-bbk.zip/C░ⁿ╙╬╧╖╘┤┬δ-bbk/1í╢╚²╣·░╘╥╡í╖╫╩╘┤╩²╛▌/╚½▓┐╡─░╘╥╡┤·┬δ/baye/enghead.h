#ifndef	_ENG_HEAD_H
#define	_ENG_HEAD_H

#include "consdef.h"
#include "graph.h"
#include "fsys.h"
#include "errcode.h"
#include "attribute.h"
#include "order.h"
#include "paccount.h"
#include "fight.h"
#include "extern.h"
#include "datman.h"
#include "fundec.h"
#include "sconst.h"
#include "sharefun.h"

#endif	/* _ENG_HEAD_H */
