#include "inc\dictafx.h"
#include "inc\keytable.h"
#include "tran.h"
#include "filedeal.h"

extern U8 *g_filedata;
extern TranType pTran;
extern U8 tranbuf[255];
extern U8 readbuf[150];
extern U8 writebuf[150];

extern U8 notestring[40];

extern U16 listtop;
extern U16 listset;
extern U16 listlen;

extern U16 fnames[LISTSHOWMAX];

extern U8	fpInf[12];
extern U16	flen;
extern TranFileType filetran;
extern FileInf fileinf;
extern U8 tranendflag;
extern U16 doff;

void SendDataPackDeal();
U8 TradeServer();

FAR U8 FileDataSend()
{
	U16 doff;
	MsgType msg;
	
	tranendflag = 0;
	if (TradeServer())
	{
		return(1);
	}
	
	SysMemcpy(filetran.fdata,(U8 *) &fileinf,sizeof(FileInf));
	filetran.type = FILEINF;
	if (SendData(&pTran,(U8 *) &filetran,sizeof(TranFileType)))
	{
		return(1);
	}
	SysMemcpy(notestring,"���ݷ�����",12);
	SysPrintString(FONTHIG * 2,FONTHIG * 2,notestring);
	
	doff = 0;
	SysTimer1Open(20);
	while(1)
	{
		if(!GuiGetMsg(&msg))		continue;
		if(!GuiTranslateMsg(&msg))	continue;
		
		if (msg.type == WM_TIMER)
		{
			if (Communication(&pTran))
			{
				SysTimer1Close();
				return(2);
			}
			
			if(IsWriterBuffer(&pTran))
				continue;
			
			if (tranendflag == 0x90)
			{
				filetran.type = CANCELSEND;
				SendData(&pTran,(U8 *) &filetran,sizeof(TranFileType));
				
				tranendflag = 0x08;
				continue;
			}
			
			if (tranendflag)
			{
				SysTimer1Close();
				return(tranendflag);
			}
			
			if (doff >= fileinf.flen)
			{
				filetran.type = FILEEND;
				SendData(&pTran,(U8 *) &filetran,sizeof(TranFileType));
				tranendflag = 0xf0;
			}
			else
			{
				filetran.type = FILEDATA;
				SysMemcpy(filetran.fdata,&g_filedata[doff],TRANDATALEN);
				SendData(&pTran,(U8 *) &filetran,sizeof(TranFileType));
				doff += TRANDATALEN;
			}
		}
		else if (msg.type == WM_COM)
		{
			if (ReceiveManage(&pTran))
			{
				SysTimer1Close();
				return(1);
			}
		}
		else if (msg.type == WM_RECEIVED)
		{
			if (ReadData(&pTran,(U8 *) &filetran))
			{
				SendDataPackDeal();
			}
		}
		else if (msg.type == WM_CHAR_FUN)
		{
			switch (msg.param)
			{
			case CHAR_EXIT:
				tranendflag = 0x90;
				break;
			}
		}
	}
}


FAR U8 TradeServer()
{
	U8 reval;
	MsgType msg;
	
	if (BuildServer(&pTran,tranbuf,readbuf,writebuf,"srv"))
		return(1);
		
	
	SysCls();
	SysMemcpy(notestring,"����������",12);
	SysPrintString(FONTHIG * 2,FONTHIG * 2,notestring);
	
	SysTimer1Open(20);
	while (1)
	{
		if(!GuiGetMsg(&msg))		continue;
		if(!GuiTranslateMsg(&msg))	continue;
		
		if (msg.type == WM_TIMER)
		{
			if (Communication(&pTran))
			{
				reval = 1;
				break;
			}
			if (IsLinked(&pTran))
			{
				reval = 0;
				break;
			}
		}
		else if (msg.type == WM_COM)
		{
			if (ReceiveManage(&pTran))
			{
				reval = 1;
				break;
			}
		}
		else if (msg.type == WM_CHAR_FUN && msg.param == CHAR_EXIT)
		{
			reval = 1;
			break;
		}
		else if ((msg.type == WM_COMMAND) && (msg.param == CMD_RETURN_HOME))
		{
			reval = 0xff;
			break;
		}
	}
	
	SysTimer1Close();
	
	return(reval);
}

void SendDataPackDeal()
{
	switch (filetran.type)
	{
	case CANCELREV:
		tranendflag = 0x08;
		break;
	default:
		tranendflag = 0x0f;
		break;
	}
}

