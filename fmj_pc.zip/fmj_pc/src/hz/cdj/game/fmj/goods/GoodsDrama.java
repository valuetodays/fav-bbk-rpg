package hz.cdj.game.fmj.goods;

/**
 * 14剧情类
 */
public class GoodsDrama extends BaseGoods {

	@Override
	protected void setOtherData(byte[] buf, int offset) {
		// TODO Auto-generated method stub

	}

}
