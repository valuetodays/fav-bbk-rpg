package hz.cdj.game.fmj.magic;

/**
 * 05特殊型 妙手空空
 * @author Chen
 *
 */
public class MagicSpecial extends BaseMagic {

	@Override
	protected void setOtherData(byte[] buf, int offset) {
	}

}
