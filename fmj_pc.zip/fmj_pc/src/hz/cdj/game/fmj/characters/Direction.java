package hz.cdj.game.fmj.characters;

public enum Direction {
    North,
    East,
    South,
    West,
}
